package com.example.sistemauniversalacesso.models;

public class admin {
}
